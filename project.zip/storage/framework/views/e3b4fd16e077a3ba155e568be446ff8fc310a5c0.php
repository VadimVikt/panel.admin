<!-- Bootstrap -->
<link href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<!-- NProgress -->
<link href="<?php echo e(asset('vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(asset('vendors/iCheck/skins/flat/green.css')); ?>" rel="stylesheet">

<!-- bootstrap-progressbar -->
<link href="<?php echo e(asset('vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet">
<!-- JQVMap -->
<link href="<?php echo e(asset('vendors/jqvmap/dist/jqvmap.min.css')); ?>" rel="stylesheet"/>
<!-- bootstrap-daterangepicker -->
<link href="<?php echo e(asset('vendors/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="<?php echo e(asset('build/css/custom.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('my.css')); ?>" rel="stylesheet">

<?php /**PATH E:\OSPanel\domains\panel.admin\resources\views/components/styles.blade.php ENDPATH**/ ?>